import java.util.ArrayList;
import java.util.List;

public class Admin {
    private int adminID;
    private String username;
    private String password;
    private String email;

    // Data managed by admin
    private List<Teacher> teachers;
    private List<Subject> subjects;
    private List<Classroom> classrooms;
    private List<TimeSlot> timeSlots;
    private List<Department> departments;

    public Admin(int adminID, String username, String password, String email) {
        this.adminID = adminID;
        this.username = username;
        this.password = password;
        this.email = email;
        this.teachers = new ArrayList<>();
        this.subjects = new ArrayList<>();
        this.classrooms = new ArrayList<>();
        this.timeSlots = new ArrayList<>();
        this.departments = new ArrayList<>();
    }

    public boolean login(String username, String password) {
        if (this.username.equals(username) && this.password.equals(password)) {
            System.out.println("Admin logged in successfully.");
            return true;
        }
        System.out.println("Invalid credentials.");
        return false;
    }

    // ── Teacher Management ──
    public void addTeacher(Teacher teacher) {
        teachers.add(teacher);
        System.out.println("Teacher added: " + teacher.getName());
    }

    public void removeTeacher(int teacherID) {
        teachers.removeIf(t -> t.getTeacherID() == teacherID);
        System.out.println("Teacher removed with ID: " + teacherID);
    }

    // ── Subject Management ──
    public void addSubject(Subject subject) {
        subjects.add(subject);
        System.out.println("Subject added: " + subject.getSubjectName());
    }

    public void removeSubject(int subjectID) {
        subjects.removeIf(s -> s.getSubjectID() == subjectID);
        System.out.println("Subject removed with ID: " + subjectID);
    }

    // ── Classroom Management ──
    public void addClassroom(Classroom classroom) {
        classrooms.add(classroom);
        System.out.println("Classroom added: " + classroom.getRoomName());
    }

    public void removeClassroom(int roomID) {
        classrooms.removeIf(c -> c.getRoomID() == roomID);
        System.out.println("Classroom removed with ID: " + roomID);
    }

    // ── TimeSlot Management ──
    public void addTimeSlot(TimeSlot slot) {
        timeSlots.add(slot);
        System.out.println("Time slot added: " + slot);
    }

    // ── Department Management ──
    public void addDepartment(Department department) {
        departments.add(department);
        System.out.println("Department added: " + department.getDepartmentName());
    }

    // ── Timetable Generation ──
    public Timetable generateTimetable(String semester) {
        System.out.println("\n--- Generating Timetable for " + semester + " ---");
        Timetable timetable = new Timetable(1, java.time.LocalDate.now().toString(), semester);
        timetable.generate(subjects, teachers, classrooms, timeSlots);
        timetable.validate();
        return timetable;
    }

    // Getters
    public List<Teacher> getTeachers() { return teachers; }
    public List<Subject> getSubjects() { return subjects; }
    public List<Classroom> getClassrooms() { return classrooms; }
    public List<TimeSlot> getTimeSlots() { return timeSlots; }
    public List<Department> getDepartments() { return departments; }
}
