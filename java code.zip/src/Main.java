public class Main {
    public static void main(String[] args) {

        // ── 1. Create Admin ──
        Admin admin = new Admin(1, "admin", "admin123", "admin@university.edu");
        admin.login("admin", "admin123");

        // ── 2. Create Department ──
        Department csDept = new Department(1, "Computer Science", "Dr. Ali Khan");
        admin.addDepartment(csDept);

        // ── 3. Create Subjects ──
        Subject dsa = new Subject(101, "Data Structures", 3, 1);
        Subject oop = new Subject(102, "OOP", 3, 1);
        Subject db  = new Subject(103, "Database Systems", 3, 1);
        Subject os  = new Subject(104, "Operating Systems", 3, 1);

        admin.addSubject(dsa);
        admin.addSubject(oop);
        admin.addSubject(db);
        admin.addSubject(os);

        csDept.addSubject(dsa);
        csDept.addSubject(oop);
        csDept.addSubject(db);
        csDept.addSubject(os);

        // ── 4. Create Teachers & Assign Subjects ──
        Teacher t1 = new Teacher(1, "Dr. Ahmed", "Algorithms", "ahmed@uni.edu");
        Teacher t2 = new Teacher(2, "Ms. Fatima", "Databases", "fatima@uni.edu");
        Teacher t3 = new Teacher(3, "Mr. Hassan", "Systems", "hassan@uni.edu");

        t1.assignSubject(dsa);
        t1.assignSubject(oop);
        t2.assignSubject(db);
        t3.assignSubject(os);

        admin.addTeacher(t1);
        admin.addTeacher(t2);
        admin.addTeacher(t3);

        csDept.addTeacher(t1);
        csDept.addTeacher(t2);
        csDept.addTeacher(t3);

        // ── 5. Create Classrooms ──
        Classroom room1 = new Classroom(1, "Room A-101", 40, "Lecture Hall");
        Classroom room2 = new Classroom(2, "Lab B-201", 30, "Laboratory");

        admin.addClassroom(room1);
        admin.addClassroom(room2);

        // ── 6. Create Time Slots ──
        TimeSlot slot1 = new TimeSlot(1, "Monday",    "08:00", "09:00");
        TimeSlot slot2 = new TimeSlot(2, "Monday",    "09:00", "10:00");
        TimeSlot slot3 = new TimeSlot(3, "Tuesday",   "08:00", "09:00");
        TimeSlot slot4 = new TimeSlot(4, "Tuesday",   "09:00", "10:00");
        TimeSlot slot5 = new TimeSlot(5, "Wednesday", "08:00", "09:00");

        admin.addTimeSlot(slot1);
        admin.addTimeSlot(slot2);
        admin.addTimeSlot(slot3);
        admin.addTimeSlot(slot4);
        admin.addTimeSlot(slot5);

        // ── 7. Generate Timetable ──
        Timetable timetable = admin.generateTimetable("Fall 2026");

        // ── 8. Display ──
        timetable.display();

        // ── 9. Export ──
        timetable.exportPDF();
    }
}
