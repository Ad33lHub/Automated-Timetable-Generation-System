import java.util.ArrayList;
import java.util.List;

public class Timetable {
    private int timetableID;
    private String generationDate;
    private String semester;
    private String status; // "Draft", "Final"
    private List<TimetableEntry> entries;

    public Timetable(int timetableID, String generationDate, String semester) {
        this.timetableID = timetableID;
        this.generationDate = generationDate;
        this.semester = semester;
        this.status = "Draft";
        this.entries = new ArrayList<>();
    }

    public boolean addEntry(TimetableEntry entry) {
        // Check for conflicts before adding
        if (hasConflict(entry)) {
            System.out.println("CONFLICT detected! Cannot add: " + entry);
            return false;
        }
        entries.add(entry);
        return true;
    }

    private boolean hasConflict(TimetableEntry newEntry) {
        for (TimetableEntry existing : entries) {
            // Same time slot check
            if (existing.getTimeSlot().getSlotID() == newEntry.getTimeSlot().getSlotID()) {
                // Teacher conflict
                if (existing.getTeacher().getTeacherID() == newEntry.getTeacher().getTeacherID()) {
                    System.out.println("Teacher conflict: " + newEntry.getTeacher().getName());
                    return true;
                }
                // Room conflict
                if (existing.getClassroom().getRoomID() == newEntry.getClassroom().getRoomID()) {
                    System.out.println("Room conflict: " + newEntry.getClassroom().getRoomName());
                    return true;
                }
            }
        }
        return false;
    }

    public boolean validate() {
        System.out.println("Validating timetable...");
        // Re-check all entries for conflicts
        for (int i = 0; i < entries.size(); i++) {
            for (int j = i + 1; j < entries.size(); j++) {
                TimetableEntry a = entries.get(i);
                TimetableEntry b = entries.get(j);
                if (a.getTimeSlot().getSlotID() == b.getTimeSlot().getSlotID()) {
                    if (a.getTeacher().getTeacherID() == b.getTeacher().getTeacherID()) {
                        System.out.println("Validation FAILED: Teacher conflict found.");
                        return false;
                    }
                    if (a.getClassroom().getRoomID() == b.getClassroom().getRoomID()) {
                        System.out.println("Validation FAILED: Room conflict found.");
                        return false;
                    }
                }
            }
        }
        System.out.println("Validation PASSED. No conflicts found.");
        return true;
    }

    public void generate(List<Subject> subjects, List<Teacher> teachers,
                         List<Classroom> rooms, List<TimeSlot> slots) {
        System.out.println("Generating timetable...");
        // Simple assignment: iterate subjects and assign available slot + room
        int slotIndex = 0;
        int roomIndex = 0;

        for (Subject subject : subjects) {
            // Find the teacher assigned to this subject
            Teacher assignedTeacher = null;
            for (Teacher t : teachers) {
                for (Subject s : t.getAssignedSubjects()) {
                    if (s.getSubjectID() == subject.getSubjectID()) {
                        assignedTeacher = t;
                        break;
                    }
                }
                if (assignedTeacher != null) break;
            }
            if (assignedTeacher == null) {
                System.out.println("No teacher found for: " + subject.getSubjectName());
                continue;
            }

            // Try to assign a slot and room
            boolean assigned = false;
            for (int s = slotIndex; s < slots.size() && !assigned; s++) {
                for (int r = roomIndex; r < rooms.size() && !assigned; r++) {
                    TimetableEntry entry = new TimetableEntry(subject, assignedTeacher, rooms.get(r), slots.get(s));
                    if (addEntry(entry)) {
                        assigned = true;
                    }
                }
            }
            slotIndex++;
            if (slotIndex >= slots.size()) {
                slotIndex = 0;
                roomIndex++;
            }
        }
        this.status = "Final";
        System.out.println("Timetable generation complete. Entries: " + entries.size());
    }

    public void exportPDF() {
        System.out.println("Exporting timetable to PDF... (placeholder)");
    }

    public void display() {
        System.out.println("\n===== TIMETABLE [" + semester + "] =====");
        System.out.println("Status: " + status + " | Generated: " + generationDate);
        System.out.println("----------------------------------------------");
        for (TimetableEntry entry : entries) {
            System.out.println(entry);
        }
        System.out.println("==============================================\n");
    }

    // Getters and Setters
    public int getTimetableID() { return timetableID; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public List<TimetableEntry> getEntries() { return entries; }
}
