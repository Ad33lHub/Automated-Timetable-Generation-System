import java.util.ArrayList;
import java.util.List;

public class Department {
    private int departmentID;
    private String departmentName;
    private String headOfDepartment;
    private List<Subject> subjects;
    private List<Teacher> teachers;

    public Department(int departmentID, String departmentName, String headOfDepartment) {
        this.departmentID = departmentID;
        this.departmentName = departmentName;
        this.headOfDepartment = headOfDepartment;
        this.subjects = new ArrayList<>();
        this.teachers = new ArrayList<>();
    }

    public void addSubject(Subject subject) {
        subjects.add(subject);
    }

    public void addTeacher(Teacher teacher) {
        teachers.add(teacher);
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    // Getters and Setters
    public int getDepartmentID() { return departmentID; }
    public void setDepartmentID(int departmentID) { this.departmentID = departmentID; }

    public String getDepartmentName() { return departmentName; }
    public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }

    public String getHeadOfDepartment() { return headOfDepartment; }
    public void setHeadOfDepartment(String headOfDepartment) { this.headOfDepartment = headOfDepartment; }

    @Override
    public String toString() {
        return "Department{" + departmentName + ", Head: " + headOfDepartment + "}";
    }
}
