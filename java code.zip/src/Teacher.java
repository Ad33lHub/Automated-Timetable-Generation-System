import java.util.ArrayList;
import java.util.List;

public class Teacher {
    private int teacherID;
    private String name;
    private String specialization;
    private String contactInfo;
    private List<Subject> assignedSubjects;

    public Teacher(int teacherID, String name, String specialization, String contactInfo) {
        this.teacherID = teacherID;
        this.name = name;
        this.specialization = specialization;
        this.contactInfo = contactInfo;
        this.assignedSubjects = new ArrayList<>();
    }

    public void assignSubject(Subject subject) {
        assignedSubjects.add(subject);
        System.out.println("Subject '" + subject.getSubjectName() + "' assigned to " + name);
    }

    public void viewSchedule(Timetable timetable) {
        System.out.println("Schedule for Teacher: " + name);
        // Display entries from timetable that belong to this teacher
    }

    public void updateAvailability(String availability) {
        System.out.println("Availability updated for " + name + ": " + availability);
    }

    // Getters and Setters
    public int getTeacherID() { return teacherID; }
    public void setTeacherID(int teacherID) { this.teacherID = teacherID; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }

    public String getContactInfo() { return contactInfo; }
    public void setContactInfo(String contactInfo) { this.contactInfo = contactInfo; }

    public List<Subject> getAssignedSubjects() { return assignedSubjects; }

    @Override
    public String toString() {
        return "Teacher{" + name + ", " + specialization + "}";
    }
}
