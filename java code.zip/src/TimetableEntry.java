public class TimetableEntry {
    private Subject subject;
    private Teacher teacher;
    private Classroom classroom;
    private TimeSlot timeSlot;

    public TimetableEntry(Subject subject, Teacher teacher, Classroom classroom, TimeSlot timeSlot) {
        this.subject = subject;
        this.teacher = teacher;
        this.classroom = classroom;
        this.timeSlot = timeSlot;
    }

    // Getters
    public Subject getSubject() { return subject; }
    public Teacher getTeacher() { return teacher; }
    public Classroom getClassroom() { return classroom; }
    public TimeSlot getTimeSlot() { return timeSlot; }

    @Override
    public String toString() {
        return timeSlot + " | " + subject.getSubjectName() +
               " | " + teacher.getName() +
               " | Room: " + classroom.getRoomName();
    }
}
