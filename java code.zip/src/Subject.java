public class Subject {
    private int subjectID;
    private String subjectName;
    private int creditHours;
    private int departmentID;

    public Subject(int subjectID, String subjectName, int creditHours, int departmentID) {
        this.subjectID = subjectID;
        this.subjectName = subjectName;
        this.creditHours = creditHours;
        this.departmentID = departmentID;
    }

    public String getDetails() {
        return "Subject{" + subjectName + ", Credits: " + creditHours + "}";
    }

    // Getters and Setters
    public int getSubjectID() { return subjectID; }
    public void setSubjectID(int subjectID) { this.subjectID = subjectID; }

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }

    public int getCreditHours() { return creditHours; }
    public void setCreditHours(int creditHours) { this.creditHours = creditHours; }

    public int getDepartmentID() { return departmentID; }
    public void setDepartmentID(int departmentID) { this.departmentID = departmentID; }

    @Override
    public String toString() {
        return getDetails();
    }
}
