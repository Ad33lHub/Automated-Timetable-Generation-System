public class Classroom {
    private int roomID;
    private String roomName;
    private int capacity;
    private String roomType; // "Lecture Hall", "Laboratory", "Seminar Room"

    public Classroom(int roomID, String roomName, int capacity, String roomType) {
        this.roomID = roomID;
        this.roomName = roomName;
        this.capacity = capacity;
        this.roomType = roomType;
    }

    public boolean checkAvailability(TimeSlot slot) {
        // Check if this room is free during the given time slot
        System.out.println("Checking availability of " + roomName + " for " + slot);
        return true; // Placeholder
    }

    public int getCapacity() {
        return capacity;
    }

    // Getters and Setters
    public int getRoomID() { return roomID; }
    public void setRoomID(int roomID) { this.roomID = roomID; }

    public String getRoomName() { return roomName; }
    public void setRoomName(String roomName) { this.roomName = roomName; }

    public void setCapacity(int capacity) { this.capacity = capacity; }

    public String getRoomType() { return roomType; }
    public void setRoomType(String roomType) { this.roomType = roomType; }

    @Override
    public String toString() {
        return "Classroom{" + roomName + ", Capacity: " + capacity + ", Type: " + roomType + "}";
    }
}
