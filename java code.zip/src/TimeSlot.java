public class TimeSlot {
    private int slotID;
    private String day;       // e.g. "Monday"
    private String startTime; // e.g. "08:00"
    private String endTime;   // e.g. "09:00"

    public TimeSlot(int slotID, String day, String startTime, String endTime) {
        this.slotID = slotID;
        this.day = day;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public boolean isAvailable() {
        // Placeholder: check if this slot is free
        return true;
    }

    public String getDuration() {
        return startTime + " - " + endTime;
    }

    // Getters and Setters
    public int getSlotID() { return slotID; }
    public void setSlotID(int slotID) { this.slotID = slotID; }

    public String getDay() { return day; }
    public void setDay(String day) { this.day = day; }

    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }

    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }

    @Override
    public String toString() {
        return day + " " + startTime + "-" + endTime;
    }
}
